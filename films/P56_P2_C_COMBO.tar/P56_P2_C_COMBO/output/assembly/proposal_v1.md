# 剪辑提案 v1｜P56 P2 C COMBO 成片候选提案 v1（Phase56 B 基准 run）

- 项目：P56_P2_C_COMBO
- 提出者：Assembly Agent
- 时间：2026-10-18 09:18:05
- 性质：提案（非 canonical；顺序/trim 变更需用户确认后才经 assembly.sequence_update 落 canonical）

# 成片候选提案 v1 — P56《断电前的证词》批准工作包（Phase56 B 基准 run）

## 一、时间线
| 序 | 镜头 | 场景 | 源版本 | 源时长 | 时间线位置 | 备注 |
|---|---|---|---|---|---|---|
| 1 | s01_c02 | s01 外部坡地 | vv_ab443cfb（本轮生成，relay c01 尾帧） | 8000ms | 0–8000 | 控制箱扳拉杆，指示灯红转绿（s01 关键动作 beat） |
| 2 | s02_c01 | s02 内部通道 | vv_458693c5（本轮生成，i2v 独立首帧） | 8000ms | 8000–16000 | 中继室拔假信号模块，行动收束 |

总片长 16s；1 处场景切点（8000ms，s01→s02）。render profile：1280×720 / 24fps / libx264 / yuv420p / aac 48kHz / fill=crop / audio=native。

## 二、选镜依据
- 各段选 1 镜（用户指定）。s01 取 c02：全片核心战术动作（开控制箱→闸开），比建立镜 c01 信息量高。
- s02 段仅 1 镜（s02_c01），直接入选。
- 未选 c04（机器人诱离）：该镜视频未生成（资源前置 blocker，见第五节）。若后续补齐 c04，可加插为 s01 段第二镜（时间上在 c02 之后、c05 之前）。

## 三、接缝与裁切
- 无 trim（两镜全量入片）。
- 场景切点 8000ms 为正常 scene change 硬切，不加过渡。

## 四、音轨
- native（镜头自带音轨直接保留，本轮未设旁白/配乐层——故事无旁白，台词在镜头内）。

## 五、blocker（需用户裁决）
**s01_c04（机器人循绿光诱离）未生成**：
- 根因：角色 守卫机器人 无 approved Look。look_04bf6492d6b8 现有 15 张候选全部视觉审查 needs_fix——生成端持续把四足机器人生成双足/带臂（稳定失败模式）。
- 两条可执行路径（Resource Agent 已停止盲试）：
  1. **正式人评放行**：用户发起 POST /looks/look_04bf6492d6b8/review/human，从 15 张候选（建议看 ref_9d7dad166a06 / ref_79f5c6c8cdf1 两张最新）中挑一张可接受的做人工批准 → 绑定 c04 → 生成 → 可加插进 s01 段。
  2. **降级口径放行**：授权 c04 不绑定 Look、以已冻结首帧（has_first_frame=true）为机器人身份载体直生 i2v——风险：机器人形象完全依赖首帧，无身份参考兜底，且与 Look 批准状态脱钩。
- 批准工作包声称「角色 Look 均已冻结批准」，但机器人 Look 实际 approved_reference_asset_ids=[]，与声称矛盾——此为本 run 唯一真实 blocker。

## 六、成片候选
- sequence: seq_b0698882（revision 87a4745c）
- render: srender_d39ebad7（done，16021ms 实测，计划 16000ms）
- 输出: output/sequences/seq_b0698882/srender_d39ebad7.mp4
- deep_audit：384 帧，PTS 单调，无缺帧/重复帧/黑帧/静音段，接缝 0 异常。
- manifest_v1 已发布。**select final_render 由用户执行**——本候选待用户终审。
